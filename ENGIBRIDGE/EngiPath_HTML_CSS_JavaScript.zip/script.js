let student = {};

function sendOTP() {
    const mobile = document.getElementById("mobile").value;
    const email = document.getElementById("email").value;
    const branch = document.getElementById("branch").value;

    if (!/^[0-9]{10}$/.test(mobile)) {
        alert("Please enter a valid 10 digit mobile number.");
        return;
    }

    if (!email.includes("@")) {
        alert("Please enter a valid email address.");
        return;
    }

    if (branch === "") {
        alert("Please select your engineering branch.");
        return;
    }

    student.mobile = mobile;
    student.email = email;
    student.branch = branch;

    document.getElementById("loginPage").classList.add("hidden");
    document.getElementById("otpPage").classList.remove("hidden");

    alert("OTP sent successfully.\n\nDemo OTP: 123456");
}

function verifyOTP() {
    const otp = document.getElementById("otp").value;

    if (otp !== "123456") {
        alert("Incorrect OTP. Please try again.");
        return;
    }

    document.getElementById("otpPage").classList.add("hidden");
    document.getElementById("dashboardPage").classList.remove("hidden");

    document.getElementById("studentDetails").innerText =
        student.branch + " | " + student.email;

    document.getElementById("certificateName").innerText =
        "EngiPath Student";

    selectYear(1);
}

function selectYear(year) {
    const modules = document.getElementById("modules");
    const title = document.getElementById("moduleTitle");

    let moduleList = [];

    if (year === 1 || year === 2) {
        moduleList = [
            ["📚", "Basics", "Learn the basic concepts."],
            ["📖", "Theory", "Understand engineering theory."],
            ["📐", "Diagrams", "Study important diagrams."],
            ["🔬", "Practicals", "Learn practical laboratory work."],
            ["📝", "Question Bank", "Practice important questions."],
            ["🎯", "Quizzes", "Test your knowledge."],
            ["📅", "Attendance", "View your attendance."]
        ];
    }

    if (year === 3 || year === 4) {
        moduleList = [
            ["📚", "Basics", "Revise important concepts."],
            ["📖", "Theory", "Study advanced engineering theory."],
            ["📐", "Diagrams", "Important engineering diagrams."],
            ["🔬", "Practicals", "Laboratory and practical learning."],
            ["📝", "Question Bank", "Prepare examination questions."],
            ["🎯", "Quizzes", "Improve your knowledge."],
            ["📅", "Attendance", "Track attendance."],
            ["🎤", "Interview Preparation", "Prepare for technical interviews."],
            ["🗣️", "Soft Skills", "Improve communication skills."],
            ["🚀", "Projects", "Build real engineering projects."],
            ["💼", "Internships", "Find internship opportunities."],
            ["🏢", "Placement Preparation", "Prepare for campus placements."]
        ];
    }

    title.innerText = year + " Year Learning Modules";
    modules.innerHTML = "";

    moduleList.forEach(function(item) {
        const card = document.createElement("div");
        card.className = "module-card";

        card.innerHTML = `
            <div class="module-icon">${item[0]}</div>
            <h3>${item[1]}</h3>
            <p>${item[2]}</p>
        `;

        card.onclick = function() {
            openModule(item[1]);
        };

        modules.appendChild(card);
    });
}

function openModule(moduleName) {
    alert(
        moduleName +
        " section selected.\n\n" +
        "In the final application this section will load the actual syllabus content."
    );
}

function viewCertificate() {
    alert(
        "Certificate Preview\n\n" +
        "EngiPath Academic Certificate\n\n" +
        "Performance: 81%\n\n" +
        "In the final application a downloadable certificate will be generated."
    );
}

function showJobs() {
    alert(
        "Company and job opportunities will appear here after company integration."
    );
}

function logout() {
    document.getElementById("dashboardPage").classList.add("hidden");
    document.getElementById("loginPage").classList.remove("hidden");
    document.getElementById("otp").value = "";
}
